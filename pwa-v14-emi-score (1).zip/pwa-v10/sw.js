// MicroFundr Service Worker v1.0
const CACHE = 'microfundr-v1';

self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => { self.clients.claim(); });

self.addEventListener('fetch', e => {
  if (e.request.url.includes('firebasedatabase') ||
      e.request.url.includes('gstatic.com/firebasejs') ||
      e.request.url.includes('googleapis')) {
    return;
  }
  e.respondWith(
    caches.open(CACHE).then(cache =>
      cache.match(e.request).then(cached => {
        const network = fetch(e.request).then(res => {
          if(res && res.status===200) cache.put(e.request, res.clone());
          return res;
        }).catch(()=>cached||new Response('Offline'));
        return cached || network;
      })
    )
  );
});
